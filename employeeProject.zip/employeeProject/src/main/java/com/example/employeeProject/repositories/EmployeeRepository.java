package com.example.employeeProject.repositories;

import com.example.employeeProject.domain.Employee;
import org.springframework.data.repository.CrudRepository;

public interface EmployeeRepository extends CrudRepository<Employee, Long> {
}
