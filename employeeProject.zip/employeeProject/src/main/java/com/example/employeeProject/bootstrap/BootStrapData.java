package com.example.employeeProject.bootstrap;

import com.example.employeeProject.domain.Employee;
import com.example.employeeProject.domain.Manager;
import com.example.employeeProject.repositories.EmployeeRepository;
import com.example.employeeProject.repositories.ManagerRepository;
import org.springframework.boot.CommandLineRunner;
import org.springframework.stereotype.Component;

import java.util.ArrayList;
import java.util.List;

@Component
public class BootStrapData implements CommandLineRunner {

    private final ManagerRepository managerRepository;
    private final EmployeeRepository employeeRepository;

    public BootStrapData(ManagerRepository managerRepository, EmployeeRepository employeeRepository) {
        this.managerRepository = managerRepository;
        this.employeeRepository = employeeRepository;
    }

    @Override
    public void run(String... args) throws Exception {

        Manager john = new Manager("John", "Doe");
        Manager kathy = new Manager("Kathy", "Eastman");

        Employee arthur = new Employee("Arthur", "Anderson", john);
        Employee becky = new Employee("Becky", "Bridges", john);
        Employee carl = new Employee("Carl", "Creston", kathy);
        Employee dana = new Employee("Dana", "Dodger", kathy);

        managerRepository.save(john);
        managerRepository.save(kathy);

        employeeRepository.save(arthur);
        employeeRepository.save(becky);
        employeeRepository.save(carl);
        employeeRepository.save(dana);

        System.out.println("Number of managers: " + managerRepository.count());
        System.out.println("Number of employees: " + employeeRepository.count());
    }
}
