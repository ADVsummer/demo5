

package com.example.employeeProject.controllers;

import com.example.employeeProject.repositories.EmployeeRepository;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;

@Controller
public class EmployeeController {

    private final EmployeeRepository employeeRepository;

    public EmployeeController(EmployeeRepository employeeRepository) {
        this.employeeRepository = employeeRepository;
    }

    @RequestMapping("/employees")
    public String getEmployees(Model model){

        model.addAttribute("employees", employeeRepository.findAll());
        //model.addAttribute("employees", "this is a test");
        //model.addAttribute("empl", "this is a test")

        return "employees/list";
        //return "list";

    }
}
